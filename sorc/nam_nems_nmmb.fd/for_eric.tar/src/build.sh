#!/bin/bash
./configure dell
. conf/modules.nems.dell
./compile.sh_pll
